import logging
import os

from sentence_transformers import SentenceTransformer
from flask import Flask, request, jsonify

app = Flask(__name__)

model_path = os.getenv("MODEL_PATH", "/Users/danika/.cache/modelscope/hub/models/BAAI/bge-m3")
print("Loading model")
model = SentenceTransformer(
    model_path,
    device="cpu"
)
print("Model loaded successfully")


@app.route("/v1/chat/completions", methods=["POST"])
def hello():
    messages = request.json.get("input", [])
    if len(messages) == 0:
        return jsonify({"error": "messages is empty"}), 400

    result = model.encode([message for message in messages])
    return jsonify({"data": [{"embedding": embedding.tolist()} for embedding in result]})


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    app.run(host="0.0.0.0", port=5001)
