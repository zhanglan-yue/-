python 3.10.16
poetry 未完全管理依赖，需要手动安装 依赖文件 requirement 
pip install -r requirements.txt --find-links=/path --no-index
