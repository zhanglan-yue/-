from flask import Flask
from flask_cors import CORS

from extensions import ext_storage, ext_milvus


def create_app() -> Flask:
    app = Flask(__name__, static_folder="webroot/static", template_folder="webroot")
    CORS(app)
    initialize_extensions(app)
    register_blueprints(app)
    return app


def initialize_extensions(app: Flask):
    ext_storage.init_app(app)


def register_blueprints(app: Flask):
    from controller.struct_label_embedding_controller import embedding_controller
    app.register_blueprint(embedding_controller)
