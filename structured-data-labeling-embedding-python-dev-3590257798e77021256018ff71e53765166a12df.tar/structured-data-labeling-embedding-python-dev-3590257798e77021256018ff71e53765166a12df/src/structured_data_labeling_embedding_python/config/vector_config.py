import logging
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings


logger = logging.getLogger(__name__)


class VectorSearchConfig(BaseSettings):

    NPROBE_SIZE: Optional[int] = Field(
        description="nprobe size for vector search",
        default=10,
    )

    TOP_K: Optional[int] = Field(
        description="top k for vector search",
        default=10,
    )

    VECTOR_DIM: Optional[int] = Field(
        description="vector dimension",
        default=1024,
    )

    RADIUS_DIM: Optional[float] = Field(
        description="radius for vector search",
        default=0.51,
    )

    METRIC_TYPE: Optional[str] = Field(
        description="metric type for vector search",
        default="COSINE",
    )

    MILVUS_COLLECTION_PREFIX: Optional[str] = Field(
        description="milvus collection prefix",
        default="sinopec_",
    )


