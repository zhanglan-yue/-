class CollectionPrefix:

    @classmethod
    @property
    def metadata(self):
        return "metadata"

    @classmethod
    @property
    def qa_history(self):
        return "history"
