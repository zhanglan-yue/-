
from config.app_env_config import StorageReviewConfig, VecDBEnvConfig

app_config = StorageReviewConfig()

vector_db_config = VecDBEnvConfig()
