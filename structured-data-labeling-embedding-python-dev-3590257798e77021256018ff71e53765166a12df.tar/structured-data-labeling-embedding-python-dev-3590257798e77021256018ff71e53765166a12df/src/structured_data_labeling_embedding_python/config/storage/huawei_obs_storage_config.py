from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings


class HuaweiCloudOBSStorageConfig(BaseSettings):
    """
    Configuration settings for Huawei Cloud Object Storage Service (OBS)
    """

    OBS_BUCKET_NAME: Optional[str] = Field(
        description="Name of the Huawei Cloud OBS bucket to store and retrieve objects (e.g., 'my-obs-bucket')",
        default=None,
    )

    OBS_ACCESS_KEY_ID: Optional[str] = Field(
        description="Access Key ID for authenticating with Huawei Cloud OBS",
        default=None,
    )

    OBS_ACCESS_KEY_SECRET: Optional[str] = Field(
        description="Secret Access Key for authenticating with Huawei Cloud OBS",
        default=None,
    )

    OBS_ENDPOINT: Optional[str] = Field(
        description="Endpoint URL for Huawei Cloud OBS (e.g., 'https://obs.cn-north-4.myhuaweicloud.com')",
        default=None,
    )

    OBS_PREFIX: Optional[str] = Field(
        description="folder name in the Huawei Cloud OBS bucket to store and retrieve objects",
        default='judge/',
    )
