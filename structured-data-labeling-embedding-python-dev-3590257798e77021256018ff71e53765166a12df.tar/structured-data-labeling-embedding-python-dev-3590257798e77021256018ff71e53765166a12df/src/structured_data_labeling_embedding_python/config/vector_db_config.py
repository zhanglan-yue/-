from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings


class VectorDBConfig(BaseSettings):
    MILVUS_HOST: Optional[str] = Field(
        description="vector db host",
        default="0.0.0.0",
    )

    TOKEN: Optional[str] = Field(
        description="vector db token",
        default="root:Milvus",
    )

    MILVUS_DB_NAME: Optional[str] = Field(
        description="vector db name",
        default="default",
    )

    MILVUS_PORT: Optional[int] = Field(
        description="vector db port",
        default=19530,
    )

    MILVUS_POOL_SIZE: Optional[int] = Field(
        description="vector db pool size",
        default=10,
    )

    MILVUS_CONNECT_TIMEOUT: Optional[int] = Field(
        description="vector db connect timeout",
        default=10,
    )

    MILVUS_MODE: Optional[str] = Field(
        description="vector db mode",
        default="cluster",
    )

    MILVUS_LITE_DATA_DIR: Optional[str] = Field(
        description="vector db lite data dir",
        default="./milvus_lite_data",
    )

    MILVUS_MAX_OVERFLOW: Optional[int] = Field(
        description="vector db max overflow",
        default=10,
    )
