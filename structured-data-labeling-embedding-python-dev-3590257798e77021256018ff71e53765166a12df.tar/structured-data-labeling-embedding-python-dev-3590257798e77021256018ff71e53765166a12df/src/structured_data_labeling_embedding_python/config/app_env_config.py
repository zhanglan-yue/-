import logging

from pydantic_settings import SettingsConfigDict

from config.storage.aliyun_oss_storage_config import AliyunOSSStorageConfig
from config.storage.huawei_obs_storage_config import HuaweiCloudOBSStorageConfig
from config.vector_config import VectorSearchConfig
from config.vector_db_config import VectorDBConfig

logger = logging.getLogger(__name__)


class StorageReviewConfig(AliyunOSSStorageConfig, HuaweiCloudOBSStorageConfig):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        # ignore extra attributes
        extra="ignore"
    )


class VecDBEnvConfig(VectorSearchConfig, VectorDBConfig):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        # ignore extra attributes
        extra="ignore"
    )
