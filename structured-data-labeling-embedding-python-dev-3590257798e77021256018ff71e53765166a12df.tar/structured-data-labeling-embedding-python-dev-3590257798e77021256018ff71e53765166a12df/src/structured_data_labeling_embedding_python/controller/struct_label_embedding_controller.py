import json
import logging
import os

from flask import Blueprint, request, jsonify, Response
from langchain.text_splitter import RecursiveCharacterTextSplitter
from config.constants import CollectionPrefix
from extensions.ext_storage import storage
from service.LLMService.genarete_sql_service import generate_sql, cleanup_file, process_file_content
from service.milvusService.CustomerMilvusService import list_collection_by_dbname
from service.milvusService.milvusClientUtils import CustomMilvusClient
from service.milvusService.milvusPreFields import labeling_submit_input_fields, labeling_submit_history_input_fields

embedding_controller: Blueprint = Blueprint('embedding_controller', __name__)


def json_response(data, status=200):
    """返回JSON响应，确保中文正常显示"""
    return Response(
        json.dumps(data, ensure_ascii=False),
        status=status,
        mimetype='application/json; charset=utf-8'
    )


@embedding_controller.route('/embedding', methods=['POST'])
def embedding_data() -> tuple:
    """处理嵌入数据的主接口"""
    # 验证请求参数
    required_params = ['storage_id', 'org_id', 'chunk_type', 'collection_name']
    if not all(request.json.get(param) for param in required_params):
        logging.error("缺少必需参数")
        return jsonify({"message": "缺少必需参数"}), 400

    # 提取请求参数
    storage_id = request.json.get('storage_id')
    org_id = request.json.get('org_id')
    collection_name = request.json.get('collection_name')
    chunk_type = request.json.get('chunk_type')

    logging.info(f"embedding_data request: {request.json}")

    # 验证chunk_type有效性
    if chunk_type not in [CollectionPrefix.metadata, CollectionPrefix.qa_history]:
        logging.error(f"参数错误: chunk_type={chunk_type}")
        return jsonify({"message": "chunk_type 参数错误"}), 400

    # 构建完整的集合名称
    full_collection_name = f"sinopec_{chunk_type}_{collection_name}"

    # 初始化文本分割器
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=4000,
        chunk_overlap=50,
        length_function=len,
        separators=["\n\n", "\n", " ", ""]
    )

    try:
        # 处理每个文件
        for single_file in storage_id.split(","):
            # 下载文件到本地
            file_local_path = f"webroot/static/files/{os.path.basename(single_file)}"
            storage.download(single_file, file_local_path)

            # 处理文件内容并生成实体
            entities = process_file_content(
                file_path=file_local_path,
                chunk_type=chunk_type,
                text_splitter=text_splitter
            )

            # 插入向量到向量库
            insert_fields = (
                labeling_submit_input_fields
                if chunk_type == CollectionPrefix.metadata
                else labeling_submit_history_input_fields
            )
            CustomMilvusClient.insert_vectors(
                full_collection_name,
                entities,
                insert_fields,
                org_id
            )

            # 清理本地文件
            cleanup_file(file_local_path)

        return jsonify({"message": "success"}), 200

    except Exception as e:
        logging.error(f"embedding_data error: {e}")
        return jsonify({"message": f"{e}"}), 500


@embedding_controller.route('/query/generate', methods=['POST'])
def query_generate_data():
    try:
        # 用户的问题
        user_question = request.json.get('user_question')
        logging.info(f"user_question: {user_question}")
        org_id = request.json.get('org_id')  # tenant
        meta_collection_names = request.json.get('meta_collection_names')
        exp_collection_names = request.json.get('bus_collection_names')
        db_type = request.json.get('db_type') if request.json.get('db_type') else "mysql"
        db_type = db_type.lower()
        if user_question is None or not isinstance(user_question, str) or len(user_question) < 2:
            logging.error("参数错误: user_question")
            raise Exception("参数错误: user_question ")

        # 搜索哪几个collection？
        if meta_collection_names is None or not isinstance(meta_collection_names, str):
            logging.error("参数错误: meta_collection_names")
            raise Exception("参数错误: meta_collection_names ")

        if exp_collection_names is None or not isinstance(exp_collection_names, str):
            logging.error("参数错误: bus_collection_names")
            raise Exception("参数错误: bus_collection_names ")

        if db_type not in ["mysql", "hive", "达梦"]:
            logging.error("参数错误: db_type")
            raise Exception("参数错误: db_type 必须是 mysql, hive 或 达梦")

        logging.info(f"meta_collection_names: {meta_collection_names}")
        logging.info(f"exp_collection_names: {exp_collection_names}")

        result = generate_sql(user_question, meta_collection_names.split(","), exp_collection_names.split(","), org_id, db_type)
        return json_response({"message": result, "code": 200}), 200
    except Exception as e:
        logging.error(f"query_generate_data error: {e}")
        return jsonify(
            {"message": f"{e}",
             "code": 500}), 500


@embedding_controller.route('/list/collection', methods=['POST'])
def list_collection():
    try:
        # 用户的租户
        org_id = request.json.get('org_id')
        if org_id is None:
            logging.error("参数错误: org_id")
            raise Exception("参数错误: org_id 不能为空")

        logging.info(f"org_id: {org_id}")

        result = list_collection_by_dbname(org_id)

        return json_response({"message": result, "code": 200}), 200
    except Exception as e:
        logging.error(f"query_generate_data error: {e}")
        return jsonify(
            {"message": f"{e}",
             "code": 500}), 500


@embedding_controller.route('/query/generate/all', methods=['POST'])
def query_generate_all_data():
    try:
        # 用户的问题
        user_question = request.json.get('user_question')
        logging.info(f"user_question: {user_question}")
        org_id = request.json.get('org_id')  # tenant
        db_type = request.json.get('db_type') if request.json.get('db_type') else "hive"
        db_type = db_type.lower()
        if user_question is None or not isinstance(user_question, str) or len(user_question) < 2:
            logging.error("参数错误: user_question")
            raise Exception("参数错误: user_question ")

        user_collections = [collection.get("collection_name") for collection in
                            CustomMilvusClient.list_collection_by_dbname(org_id)]
        meta_collection_names = []
        exp_collection_names = []
        for user_collection in user_collections:
            if "meta_" in user_collection:
                meta_collection_names.append(user_collection)
            elif "history_" in user_collection:
                exp_collection_names.append(user_collection)

        result = generate_sql(user_question, meta_collection_names, exp_collection_names, org_id, db_type)
        return json_response({"message": result, "code": 200}), 200
    except Exception as e:
        logging.error(f"query_generate_data error: {e}")
        return jsonify(
            {"message": f"{e}",
             "code": 500}), 500
