os.environ['PYTHONIOENCODING'] = 'UTF-8'
app.run(host=os.getenv("FLASK_HOST"), port=os.getenv("FLASK_PORT"), threaded=True)