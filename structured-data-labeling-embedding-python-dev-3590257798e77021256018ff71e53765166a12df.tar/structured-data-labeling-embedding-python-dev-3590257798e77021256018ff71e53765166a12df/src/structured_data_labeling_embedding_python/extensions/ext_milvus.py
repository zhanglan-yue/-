import threading
import queue
import time
from pymilvus import connections, utility

from config import vector_db_config


class MilvusConnectionPool:
    def __init__(self):
        self.host = vector_db_config.MILVUS_HOST
        self.port = vector_db_config.MILVUS_PORT
        self.pool_size = vector_db_config.MILVUS_POOL_SIZE | 20
        self.max_overflow = vector_db_config.MILVUS_MAX_OVERFLOW | 10
        self._pool = queue.Queue(maxsize=self.pool_size)
        self._overflow = 0
        self._lock = threading.Lock()

        # 初始化连接池
        self._initialize_pool()

    def _initialize_pool(self):
        """初始化连接池"""
        for _ in range(self.pool_size):
            conn = self._create_connection()
            self._pool.put(conn)

    def _create_connection(self):
        """创建新的 Milvus 连接"""
        # 使用唯一别名创建连接
        alias = f"pool_connection_{threading.get_ident()}_{time.time()}"
        connections.connect(alias=alias, host=self.host, port=self.port)
        return alias

    def get_connection(self):
        """
        从连接池获取一个连接

        Returns:
            str: Milvus 连接别名
        """
        try:
            # 尝试从池中获取连接，设置超时时间避免无限等待
            return self._pool.get(timeout=5)
        except queue.Empty:
            # 池中无可用连接，尝试创建新的连接
            with self._lock:
                if self._overflow < self.max_overflow:
                    try:
                        conn = self._create_connection()
                        self._overflow += 1
                        return conn
                    except Exception as e:
                        raise Exception(f"创建新连接失败: {str(e)}")
                else:
                    raise Exception("连接池已满，无法获取连接")

    def release_connection(self, conn):
        """
        释放连接回连接池

        Args:
            conn: 要释放的连接别名
        """
        # 检查连接是否有效
        try:
            utility.list_collections(using=conn)

            with self._lock:
                if self._overflow > 0 and not self._pool.full():
                    # 如果是溢出连接且池未满，直接放回池中
                    self._pool.put(conn)
                    self._overflow -= 1
                elif not self._pool.full():
                    # 如果是池内连接，放回池中
                    self._pool.put(conn)
                else:
                    # 池已满，关闭连接
                    connections.disconnect(conn)
                    if self._overflow > 0:
                        self._overflow -= 1
        except Exception:
            # 连接无效，创建新连接替代
            try:
                new_conn = self._create_connection()
                if not self._pool.full():
                    self._pool.put(new_conn)
                else:
                    connections.disconnect(new_conn)
                    if self._overflow > 0:
                        self._overflow -= 1
            except Exception:
                # 创建新连接失败，忽略
                pass

    def close_all(self):
        """关闭所有连接"""
        while not self._pool.empty():
            try:
                conn = self._pool.get_nowait()
                connections.disconnect(conn)
            except queue.Empty:
                break

        # 关闭所有溢出连接
        with self._lock:
            self._overflow = 0


milvus_pool = MilvusConnectionPool()
