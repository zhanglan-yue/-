import base64
import hashlib
import logging
import posixpath
from collections.abc import Generator

from obs import ObsClient, GetObjectHeader

from config import app_config
from extensions.storage.base_storage import BaseStorage


class HuaweiObsStorage(BaseStorage):
    """Implementation for Huawei OBS storage."""

    def __init__(self):
        super().__init__()
        self.folder = app_config.OBS_PREFIX
        self.bucket_name = app_config.OBS_BUCKET_NAME
        self.client = ObsClient(access_key_id=app_config.OBS_ACCESS_KEY_ID,
                                secret_access_key=app_config.OBS_ACCESS_KEY_SECRET, server=app_config.OBS_ENDPOINT)

    def save(self, filename, data):
        pass
        # md5 = hashlib.md5()
        # md5.update(data)
        # content_md5 = base64.standard_b64encode(md5.digest())
        # self.client.putObject()

    def load_once(self, filename: str) -> bytes:
        response = self.client.getObject(bucket_name=self.bucket_name, key=filename)
        data: bytes = response.data.read()
        return data

    def load_stream(self, filename: str) -> Generator:
        response = self.client.getObject(self.bucket_name, filename).data
        while chunk := response.read(4096):
            yield chunk

    def download(self, filename, target_filepath) -> bool:
        res = self.client.getObject(self.bucket_name, self.__wrapper_folder_filename(filename), target_filepath, headers = GetObjectHeader())
        if res.status < 300:
            return True
        logging.info("failed to download %s", filename)
        return False

    def exists(self, filename):
        pass
        # res = self.client.get_object_meta_data(bucket_name=self.bucket_name, key=filename)
        # if res is None:
        #     return False
        # return True

    def delete(self, filename):
        pass
        # self.client.delete_object(bucket_name=self.bucket_name, key=filename)

    def __wrapper_folder_filename(self, filename: str) -> str:
        return posixpath.join(self.folder, filename) if self.folder else filename
