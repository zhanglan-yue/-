from enum import Enum


class StorageType(str, Enum):
    ALIYUN_OSS = "aliyun-oss"
    HUAWEI_OBS = "huawei-obs"
