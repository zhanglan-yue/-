import logging

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# 配置参数
PROXIES = {

}
RETRIES = 3  # 最大重试次数
BACKOFF_FACTOR = 5  # 指数退避因子
TIMEOUT = 100  # 超时时间/秒
STATUS_FORCE_RETRY = [429, 500, 502, 503, 504]  # 需要重试的状态码

# 随机User-Agent列表
USER_AGENTS = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15"

DISABLE_SSL = True  # 禁用证书验证


def create_retry_session():
    """创建带重试机制的Session对象"""
    session = requests.Session()

    # 配置重试策略
    retry_strategy = Retry(
        total=RETRIES,
        backoff_factor=BACKOFF_FACTOR,
        status_forcelist=STATUS_FORCE_RETRY,
        allowed_methods=["GET", "POST", "PUT", "DELETE"]  # 需要重试的HTTP方法
    )

    # 为HTTP和HTTPS适配器添加重试机制
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)

    return session


def make_request(url, method="GET", **kwargs):
    """发送带代理和重试机制的请求"""
    session = create_retry_session()
    headers = kwargs.pop('headers', {})

    headers.setdefault('User-Agent', USER_AGENTS)
    # SSL 禁用
    kwargs['verify'] = not DISABLE_SSL
    try:
        response = session.request(
            method=method,
            url=url,
            proxies=PROXIES,
            timeout=TIMEOUT,
            headers=headers,
            **kwargs
        )
        response.raise_for_status()  # 检查HTTP错误
        return response

    except requests.exceptions.RequestException as e:
        logging.error(f"请求失败: {url} - {e}")
