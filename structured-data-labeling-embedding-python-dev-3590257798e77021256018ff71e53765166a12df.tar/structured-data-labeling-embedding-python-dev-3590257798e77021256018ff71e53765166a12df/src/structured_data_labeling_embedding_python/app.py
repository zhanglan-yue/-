import logging
import os

from dotenv import load_dotenv

# 全局日志配置
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
# 设置全局编码
os.environ['PYTHONIOENCODING'] = 'UTF-8'

load_dotenv()   #加载env文件

from appfactory import create_app

app = create_app()

if __name__ == '__main__':
    # logging.basicConfig(level=logging.INFO)
    # os.environ['PYTHONIOENCODING'] = 'UTF-8'
    app.run(host=os.getenv("FLASK_HOST"), port=os.getenv("FLASK_PORT"), threaded=True)
