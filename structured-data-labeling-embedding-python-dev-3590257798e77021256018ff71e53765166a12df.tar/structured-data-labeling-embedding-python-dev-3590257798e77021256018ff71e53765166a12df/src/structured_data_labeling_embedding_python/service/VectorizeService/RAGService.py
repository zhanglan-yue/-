import json
import logging
import os

from utils.RequestsProxy import make_request

embedding_api_url = os.getenv("EMBEDDING_API_URL")
reranker_api_url = os.getenv("RERANKER_API_URL")


def vectorize_text(batch_sentences):
    """
    向量化文本

    参数:
        text: 输入文本

    返回:
        向量化表示
    """
    if len(batch_sentences) == 0:
        logging.info("batch_sentences is empty")
        batch_sentences = ["meanness"]

    filter_sentences = []
    for sentence in batch_sentences:
        sentence = sentence[:5000] if len(sentence) >= 5000 else sentence
        if len(sentence) == 0:
            continue
        filter_sentences.append(sentence)

    if len(filter_sentences) == 0:
        logging.info("filter_sentences is empty")
        filter_sentences = ["meanness"]

    # 初始化总结果列表（仅保留data部分，最终会包装为原格式）
    all_data = []
    batch_size = 500
    # 计算需要分多少批
    total_batches = (len(filter_sentences) + batch_size - 1) // batch_size
    logging.info(f"Total sentences to vectorize: {len(filter_sentences)}, "
                 f"batch size: {batch_size}, total batches: {total_batches}")

    # 分批次处理
    for i in range(total_batches):
        # 计算当前批次的起始和结束索引
        start_idx = i * batch_size
        end_idx = min((i + 1) * batch_size, len(filter_sentences))
        current_batch = filter_sentences[start_idx:end_idx]
        logging.info(f"Processing batch {i + 1}/{total_batches}, size: {len(current_batch)}")

        # 构建请求体
        request_body = {
            "model": f"{os.getenv('EMBEDDING_MODEL')}",
            "input": current_batch
        }

        # 发送请求
        response = make_request(
            embedding_api_url,
            method="POST",
            json=request_body,
            headers={
                "Authorization": f"{os.getenv('EMBEDDING_API_KEY')}",
                "Content-Type": "application/json"
            }
        )

        # 处理响应
        if response is None:
            raise Exception(f"vectorize_text request failed in batch {i + 1}, response is None")

        if response.status_code != 200:
            response.raise_for_status()

        # 解析当前批次结果并合并data部分
        batch_result = json.loads(response.content)
        all_data.extend(batch_result.get("data", []))  # 合并各批次的data列表

    # 保持原返回格式：包含data字段的字典
    return {"data": all_data}


def rerank_text(recall_list: list[str], query: str, **kwargs) -> list[str]:
    if len(recall_list) == 0:
        logging.info("recall_list is empty")
        return []

    top_n = kwargs.get("top_n", min(int(len(recall_list)), 5))

    batch = [item[:500] if len(item) >= 500 else item for item in recall_list]

    request_body = {
        "model": f"{os.getenv('RERANKER_MODEL')}",
        "parameters": {
            "raw_scores": True
        },
        "query": query,
        "texts": batch,
        "top_n": top_n
    }

    response = make_request(reranker_api_url, method="POST", json=request_body, headers={
        "Authorization": f"{os.getenv('RERANKER_API_KEY')}",
        "Content-Type": "application/json"
    })
    try:
        data = json.loads(response.content)
    except Exception as e:
        raise e

    data_sorted = sorted(data, key=lambda x: x["score"], reverse=True)

    reranked_texts = [recall_list[item["index"]] for item in data_sorted]

    return reranked_texts[:top_n]
