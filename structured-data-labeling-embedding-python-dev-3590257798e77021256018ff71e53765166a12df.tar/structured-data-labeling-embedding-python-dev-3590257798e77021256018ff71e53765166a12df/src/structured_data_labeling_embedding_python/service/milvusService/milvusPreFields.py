from pymilvus import DataType


def filter_output_fields(input_fields: []):
    output_fields = []
    for f in input_fields:
        if isinstance(f, dict):
            if f.get("datatype") != "FLOAT_VECTOR":
                output_fields.append(f["field_name"])
        else:
            if f.datatype != DataType.FLOAT_VECTOR:
                output_fields.append(f.field_name)
    return output_fields


labeling_submit_input_fields = [
    {"field_name": "uid", "datatype": DataType.INT64, "is_primary": True},
    {"field_name": "embedding", "datatype": DataType.FLOAT_VECTOR, "dim": 1024},
    {"field_name": "content", "datatype": DataType.VARCHAR, "max_length": 8192},
    {"field_name": "table_name", "datatype": DataType.VARCHAR, "max_length": 8192},
    {"field_name": "doc_flag", "datatype": DataType.VARCHAR, "max_length": 100},
    {"field_name": "chunk_index", "datatype": DataType.VARCHAR, "max_length": 100},
    {"field_name": "total_chunks", "datatype": DataType.VARCHAR, "max_length": 100},
    {"field_name": "table_name_embedding", "datatype": DataType.FLOAT_VECTOR, "dim": 1024},
    {"field_name": "created_at", "datatype": DataType.INT64},
]

labeling_submit_output_fields = filter_output_fields(labeling_submit_input_fields)


labeling_submit_history_input_fields = [
    {"field_name": "uid", "datatype": DataType.INT64, "is_primary": True},
    {"field_name": "embedding", "datatype": DataType.FLOAT_VECTOR, "dim": 1024},
    {"field_name": "content", "datatype": DataType.VARCHAR, "max_length": 8192},
    {"field_name": "question", "datatype": DataType.VARCHAR, "max_length": 8192},
    {"field_name": "question_embedding", "datatype": DataType.FLOAT_VECTOR, "dim": 1024},
    {"field_name": "created_at", "datatype": DataType.INT64}
]