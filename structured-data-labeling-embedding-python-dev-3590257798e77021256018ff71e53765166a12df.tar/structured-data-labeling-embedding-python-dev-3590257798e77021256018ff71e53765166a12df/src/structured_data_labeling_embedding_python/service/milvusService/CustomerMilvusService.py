from service.milvusService.milvusClientUtils import CustomMilvusClient


def list_collection_by_dbname(db_name):
    return CustomMilvusClient.list_collection_by_dbname(db_name)
