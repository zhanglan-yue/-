import logging
import time

from pymilvus import utility, DataType, MilvusClient
from functools import lru_cache

from config import vector_db_config

logger = logging.getLogger(__name__)


# 动态获取租户连接
# @lru_cache(maxsize=10)
def _get_milvus_client(db_name: str = "default") -> MilvusClient:
    """获取指定数据库的Milvus客户端"""
    client = MilvusClient(
        uri=f"http://{vector_db_config.MILVUS_HOST}:{vector_db_config.MILVUS_PORT}"
    )

    # 检查数据库是否存在
    dbs = client.list_databases()
    if db_name not in [db for db in dbs]:
        logger.info(f"Database {db_name} not found, creating it...")
        client.create_database(db_name=db_name)

    # 切换到指定数据库并返回客户端
    client.use_database(db_name=db_name)
    return client


def get_milvus_client(db_name: str = "default") -> MilvusClient:
    """获取指定数据库的Milvus客户端"""
    client = _get_milvus_client(db_name)
    # if _get_milvus_client.cache_info().hits > 0:
    #     logger.info(f"Retrieved Milvus client for database: {db_name} from cache")
    # else:
    #     logger.info(f"Created Milvus client for database: {db_name}")
    return client


# new version
class CustomMilvusClient:

    # db_name 租户id 向量数据库 库名
    @staticmethod
    def vector_search(collection_names: list, query_vectors, search_params, top_k=20, fields=None, **kwargs) -> list:

        anns_field = kwargs.get("anns_field")
        db_name = kwargs.get("db_name")

        if db_name is None:
            raise ValueError("db_name is required")

        if anns_field is None:
            raise ValueError("anns_field is required")

        if fields is None:
            raise ValueError("fields is required")

        for collection_name in collection_names:
            CustomMilvusClient.validate_collection(collection_name, fields, db_name)

        # 确定返回字段（非向量字段）
        output_fields = []
        for f in fields:
            if isinstance(f, dict):
                if f.get("datatype") != DataType.FLOAT_VECTOR:
                    output_fields.append(f["field_name"])
            else:
                if f.datatype != DataType.FLOAT_VECTOR:
                    output_fields.append(f.field_name)

        client = get_milvus_client(db_name)

        if collection_names is None or len(collection_names) == 0:
            collection_names = client.list_collections()

        content_results = []

        for collection_name in collection_names:
            content_results.append(client.search(
                collection_name=collection_name,
                data=query_vectors,
                anns_field=anns_field,
                search_params=search_params,
                limit=top_k,
                output_fields=output_fields
            ))

        # 处理结果
        processed = []
        for sin in content_results:
            for i, hits in enumerate(sin):
                if "doc_flag" in output_fields:
                    # 提取所有唯一的doc_flag
                    unique_doc_flags = set()
                    for hit in hits:
                        doc_flag = hit.entity.get('doc_flag')
                        if doc_flag:
                            unique_doc_flags.add(doc_flag)

                    # 为每个唯一的doc_flag查询所有相关数据
                    all_results = []
                    for doc_flag in unique_doc_flags:
                        # 查询该doc_flag的所有数据
                        expr = f"doc_flag == '{doc_flag}'"
                        for collection_name in collection_names:
                            # 按doc_flag查询所有相关数据
                            doc_hits = client.query(
                                collection_name=collection_name,
                                filter=expr,
                                output_fields=output_fields
                            )
                            all_results.extend(doc_hits)

                    # 按doc_flag分组
                    doc_groups = {}
                    for hit in all_results:
                        doc_flag = hit.get('doc_flag')
                        if doc_flag not in doc_groups:
                            doc_groups[doc_flag] = []
                        doc_groups[doc_flag].append(hit)

                    # 对每个分组按chunk_index排序并收集结果
                    group_results = []
                    for group in doc_groups.values():
                        # 按chunk_index转换为整数排序
                        sorted_group = sorted(
                            group,
                            key=lambda x: int(x.get('chunk_index', 0))
                        )
                        group_results.extend(sorted_group)

                    processed.append({
                        "query_id": i,
                        "results": group_results
                    })
                else:
                    processed.append({
                        "query_id": i,
                        "results": [{
                            **{field: hit.fields.get(field) for field in output_fields}
                        } for hit in hits]
                    })
        # if len(processed) > 1:
        #     for i in range(1, len(processed)):
        #         for sin in processed[i]['results']:
        #             processed[0]['results'].append(sin)

        return processed

    @staticmethod
    def insert_vectors(collection_name, entities, fields, db_name):

        if db_name is None:
            raise ValueError("db_name is required")

        client = get_milvus_client(db_name)

        CustomMilvusClient.validate_collection(collection_name, fields, db_name)
        # 添加时间戳
        timestamp = int(time.time())
        for entity in entities:
            entity["created_at"] = timestamp

        client.insert(
            collection_name,
            entities
        )

        # 最终刷新确保数据持久化
        # client.flush(collection_name)

    @staticmethod
    def get_collection_stats(collection_name, db_name):
        """
        获取集合统计信息

        参数:
            collection_name (str): 集合名称

        返回:
            dict: 集合统计信息，包含:
                - row_count: 实体数量
                - partitions: 分区信息
                - indexes: 索引信息
                或错误信息
        """
        if db_name is None:
            raise ValueError("db_name is required")

        client = get_milvus_client(db_name)

        if client.has_collection(collection_name):
            stats = client.get_collection_stats(collection_name)
            return {
                "row_count": stats.get("row_count", 0),
                "partitions": stats.get("partitions", []),
                "indexes": utility.list_indexes(collection_name)
            }

        return {"error": f"Collection {collection_name} does not exist"}

    @staticmethod
    def delete_collection(collection_name, db_name):
        if db_name is None:
            raise ValueError("db_name is required")

        client = get_milvus_client(db_name)

        if client.has_collection(collection_name):
            client.drop_collection(collection_name)
            return {"success": True, "message": f"Collection {collection_name} deleted"}
        return {"success": False, "message": f"Collection {collection_name} does not exist"}

    @staticmethod
    def validate_collection(collection_name, fields, db_name):
        if db_name is None:
            raise ValueError("db_name is required")

        client = get_milvus_client(db_name)

        if not fields:
            raise ValueError("fields is required")

        if not collection_name:
            raise ValueError("collection_name is required")

        if not client.has_collection(collection_name):
            schema = MilvusClient.create_schema(
                auto_id=True,
                enable_dynamic_field=False,
            )
            index_params = client.prepare_index_params()

            for field in fields:
                schema.add_field(**field)
                if field.get("datatype") == DataType.FLOAT_VECTOR:
                    index_params.add_index(
                        field_name=field["field_name"],
                        index_type="IVF_FLAT",
                        metric_type=vector_db_config.METRIC_TYPE,
                        params={"nlist": 64}
                    )

            client.create_collection(collection_name, schema=schema, index_params=index_params)

    @staticmethod
    def list_collection_by_dbname(db_name):
        if not db_name:
            raise ValueError("db_name is required")

        client = get_milvus_client(db_name)
        collection_info_list = []
        collections = client.list_collections()
        from pymilvus import hybridts_to_datetime

        for collection_name in collections:
            client.flush(collection_name)
            # client.compact(collection_name)
            logging.info(len(client.query(
                collection_name,
                output_fields=["*"],
                limit=1000
            )))
            # 获取集合描述信息
            coll_desc = client.describe_collection(collection_name=collection_name)
            # 获取集合统计信息
            coll_stats = client.get_collection_stats(collection_name=collection_name)

            collection_info_list.append({
                "collection_name": collection_name,
                "database_name": db_name,
                "entity_count": coll_stats.get("row_count", 0),
                "created_time": hybridts_to_datetime(coll_desc.get("created_timestamp", 0)).strftime("%Y-%m-%d %H:%M:%S"),
                "update_time": hybridts_to_datetime(coll_desc.get("update_timestamp", 0)).strftime("%Y-%m-%d %H:%M:%S"),
                "consistency_level": coll_desc.get("consistency_level", "")
            })

        return collection_info_list
