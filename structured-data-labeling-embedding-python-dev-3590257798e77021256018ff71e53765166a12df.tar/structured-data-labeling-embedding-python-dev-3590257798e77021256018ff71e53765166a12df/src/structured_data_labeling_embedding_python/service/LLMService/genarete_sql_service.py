import hashlib
import json
import logging
import os
import re
from typing import List, Dict, Any

from langchain_core.prompts import ChatPromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate
from langchain_openai.chat_models import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser
from langchain.text_splitter import RecursiveCharacterTextSplitter

import httpx
from config import vector_db_config
from config.constants import CollectionPrefix
from service.VectorizeService.RAGService import vectorize_text, rerank_text
from service.milvusService.milvusPreFields import labeling_submit_history_input_fields, labeling_submit_input_fields
from service.milvusService.milvusClientUtils import CustomMilvusClient

sql_gen_template = ChatPromptTemplate.from_messages(
    [
        SystemMessagePromptTemplate.from_template(
            """
            作为SQL专家，请严格按照以下步骤生成查询SQL：
            1. 理解用户问题并提取查询需求：仔细分析用户输入，思考可能关联的表字段，明确其查询意图和所需数据。
            2. 判断需求是否与数据库相关：
            如果需求与数据库无关（例如，非数据查询问题），则直接回复“未生成有效的sql语句”。
            如果相关，则继续下一步。
            3. 处理历史相似问题:
            如果历史相似问题为空，则忽略此步。
            4. 处理表结构信息:
            若存在历史相似问题，但缺少表结构信息，需先依据历史相似问题尝试生成 SQL 语句。
            如果未包含历史相似问题，则根据用户问题，结合表结构信息生成sql。
            如果历史信息和表结构信息都存在，则严格依据历史信息逻辑生成sql
            5. 生成SQL语句：
            根据以上步骤，生成符合用户需求的SQL语句。
            
            背景信息：
            1. 数据库表结构信息：{table_info}
            2. 历史相似问题：{QA_history}
            3. 数据库类型：{db_type}
            
            注意：
            1. 若未提供数据库类型，请默认生成兼容Hive的标准SELECT语句，并注意：
                  Hive支持CURRENT_DATE(),不支持CURRENT_DATE;
                  Hive支持COALESCE，不支持IFNULL;
                  分组求和必须使用SUM()函数;
                  当前年份减一使用YEAR(CURRENT_DATE())-1，不支持DATE_SUB(CURRENT_DATE(), INTERVAL 1 YEAR)。
            2. 一步一步思考，输出每一步的思考过程，确保生成的SQL语句逻辑正确。
            3. 确保最终生成的SQL语句被包含在<result>标签中。
            4. 中文别名需使用反引号（`）包裹，不要出现括号，比如审减额(万元)替换为审减额_万元。
            5. 若未成功生成sql语句且满足前两步，则依据用户问题，结合表结构信息生成sql。
            
            示例1：
            输入：查询工资超过5000的员工姓名和工资
            输出：
            1. 理解用户问题并提取查询需求：查询工资超过5000的员工姓名和工资
            2. 判断需求是否与数据库相关：相关
            3. 处理历史相似问题: 无
            4. 处理表结构信息: 有
            5. 生成SQL语句：
            <result>SELECT name, salary FROM employees WHERE salary > 5000</result>
            示例2：
            输入：今天天气真好
            输出：
            1. 理解用户问题并提取查询需求：今天天气真好
            2. 判断需求是否与数据库相关：无关
            <result>未生成有效的sql语句</result>
            示例3：
            输入：查询所有地区的天气
            输出：
            1. 理解用户问题并提取查询需求：查询所有地区的天气
            2. 判断需求是否与数据库相关：相关
            3. 处理历史相似问题: 无
            4. 处理表结构信息: 有，但不相关
            5. 生成SQL语句：
            <result>未生成有效的sql语句</result>
            """
        ),
        HumanMessagePromptTemplate.from_template(
            """
            以下为用户的问题：
            {user_question}
            """
        )
    ]
)


def call_llm(user_question: str, table_info, his_rerank_result: list, db_type: str) -> str:
    chain = sql_gen_template | ChatOpenAI(
        model_name=os.getenv("LLM_MODEL"),
        base_url=os.getenv("LLM_API_URL"),
        api_key=os.getenv("LLM_API_KEY"),
        http_client=httpx.Client(verify=False)
    ) | StrOutputParser()

    resp = chain.invoke({
        "user_question": user_question,
        "table_info": str(table_info),
        "QA_history": str(his_rerank_result),
        "db_type": db_type
    })

    logging.info(resp)
    try:
        match = re.findall(r'<result>(.*?)</result>', resp, re.DOTALL)
        if match:
            return match[0].strip()
    except Exception as e:
        logging.error(f"generate_sql error: {e}")
        return "未生成有效的sql语句"


def _filter_empty_collection(user_collections: list) -> list:
    tmp_list = []
    for user_collection in user_collections:
        if user_collection != "":
            tmp_list.append(user_collection)

    return tmp_list


def get_metadata_table_info(user_collections: list, vec, db_name: str, **kwargs) -> list:
    user_collections = _filter_empty_collection(user_collections)

    if len(user_collections) == 0 and len(_filter_empty_collection(kwargs.get("another_collection", []))) > 0:
        logging.info(f"user_collections is empty, find all collections in db_name: {db_name}")
        user_collections = [collection.get("collection_name") for collection in
                            CustomMilvusClient.list_collection_by_dbname(db_name)]

        tmp_list = []
        for user_collection in user_collections:
            if "metadata_" in user_collection:
                tmp_list.append(user_collection)

        user_collections = tmp_list

    if user_collections is None or len(user_collections) == 0:
        return []

    recall_results = CustomMilvusClient.vector_search(
        [f"{user_collection}" for user_collection in user_collections],
        [vec],
        anns_field="embedding",
        top_k=5,
        search_params={
            "metric_type": vector_db_config.METRIC_TYPE,
            "params": {"nprobe": 64},
            "radius": 0.445
        },
        fields=labeling_submit_input_fields,
        db_name=db_name
    )
    logging.info(f"recall_results: {json.dumps(recall_results, ensure_ascii=False)}")
    return recall_results[0]["results"]


def get_metadata_table_info_by_table_name(user_collections: list, vec, db_name: str, **kwargs) -> list:
    # 如果user_collections为空，则返回找当前数据库所有表的信息
    user_collections = _filter_empty_collection(user_collections)
    if len(user_collections) == 0 and len(_filter_empty_collection(kwargs.get("another_collection", []))) > 0:
        logging.info(f"user_collections is empty, find all collections in db_name: {db_name}")
        user_collections = [collection.get("collection_name") for collection in
                            CustomMilvusClient.list_collection_by_dbname(db_name)]

        tmp_list = []
        for user_collection in user_collections:
            if "metadata_" in user_collection:
                tmp_list.append(user_collection)

        user_collections = tmp_list

    if user_collections is None or len(user_collections) == 0:
        return []

    recall_results = CustomMilvusClient.vector_search(
        [f"{user_collection}" for user_collection in user_collections],
        [vec],
        anns_field="table_name_embedding",
        top_k=10,
        search_params={
            "metric_type": vector_db_config.METRIC_TYPE,
            "params": {"nprobe": 64},
            "radius": 0.65
        },
        fields=labeling_submit_input_fields,
        db_name=db_name
    )

    content_recall_results = CustomMilvusClient.vector_search(
        [f"{user_collection}" for user_collection in user_collections],
        [vec],
        anns_field="embedding",
        top_k=10,
        search_params={
            "metric_type": vector_db_config.METRIC_TYPE,
            "params": {"nprobe": 64},
            "radius": 0.65
        },
        fields=labeling_submit_input_fields,
        db_name=db_name
    )

    logging.info(f"recall_results: {json.dumps(recall_results, ensure_ascii=False)}")
    return recall_results[0]["results"] + content_recall_results[0]["results"]


def generate_sql(user_question: str, meta_collections: list, exp_collections: list, vdb_name: str, db_type: str) -> str:
    # 向量化用户问题
    user_question_vector = vectorize_text([user_question])
    query_vector = user_question_vector["data"][0]["embedding"]
    his_recall_results = []
    if exp_collections != [""]:
        # history
        his_recall_results = CustomMilvusClient.vector_search(
            [f"{user_collection}" for user_collection in exp_collections],
            [query_vector],
            anns_field="question_embedding",
            top_k=3,
            search_params={
                "metric_type": vector_db_config.METRIC_TYPE,
                "params": {"nprobe": 64},
                "radius": 0.65
            },
            fields=labeling_submit_history_input_fields,
            db_name=vdb_name
        )

        # 召回列表为空，或每个列表中的results都为空
        tmp_flag = True
        for his_recall_result in his_recall_results:
            if len(his_recall_result.get("results", [])) > 0:
                tmp_flag = False
                break

        if tmp_flag:
            # 按用户问题召回
            logging.info("none familiar history")
            all_recall_results = get_metadata_table_info(meta_collections, query_vector, vdb_name,
                                                         another_collection=exp_collections)
            return call_llm(user_question, all_recall_results, [], db_type)

    his_tmp_list = []
    for index, items in enumerate(his_recall_results):
        his_tmp_list.extend(item["content"] for item in items["results"])

    logging.info(f"his_tmp_list:{json.dumps(his_tmp_list, ensure_ascii=False)}")

    his_rerank_result = rerank_text(his_tmp_list, user_question)

    logging.info(f"his_rerank_result:{json.dumps(his_rerank_result, ensure_ascii=False)}")

    his_rerank_result_output = []
    retained_fields = ["output"]
    for item in his_rerank_result:
        data = json.loads(item.strip())
        iltered_data = [v for k, v in data.items() if k in retained_fields]
        result_str = ", ".join(map(str, iltered_data))
        his_rerank_result_output.append(result_str)

    logging.info(f"his_rerank_result_output:{json.dumps(his_rerank_result_output, ensure_ascii=False)}")

    his_rerank_result_output_vector = vectorize_text(his_rerank_result_output)
    output_vectors = his_rerank_result_output_vector["data"]

    all_recall_results = []
    for single_output_result in output_vectors:
        single_output_vec = single_output_result["embedding"]
        all_recall_results.extend(get_metadata_table_info_by_table_name(meta_collections, single_output_vec, vdb_name,
                                                                        another_collection=exp_collections))

    logging.info(f"all_recall_results: {json.dumps(all_recall_results, ensure_ascii=False)}")

    # 去重
    tmp_list = set()
    for index, items in enumerate(all_recall_results):
        tmp_list.add(items["content"])

    return call_llm(user_question, tmp_list, his_rerank_result, db_type)


def process_file_content(
        file_path: str,
        chunk_type: str,
        text_splitter: RecursiveCharacterTextSplitter
) -> List[Dict[str, Any]]:
    """处理文件内容并生成要插入向量库的实体"""
    # 读取文件内容
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    if chunk_type == CollectionPrefix.qa_history:
        return process_qa_history(content)
    elif chunk_type == CollectionPrefix.metadata:
        return process_metadata(content, text_splitter)
    else:
        raise ValueError(f"不支持的chunk_type: {chunk_type}")


def process_qa_history(content: str) -> List[Dict[str, Any]]:
    """处理问答历史类型的内容"""
    data = content.split("@@@")
    user_questions = []

    # 提取用户问题
    for line in data:
        json_data = json.loads(line)
        user_questions.append(json_data.get('input', ""))

    # 向量化处理
    question_vecs = vectorize_text(user_questions)["data"]
    content_vecs = vectorize_text(data)["data"]

    # 验证向量长度一致性
    if len(question_vecs) != len(data) or len(content_vecs) != len(data):
        raise Exception(f"向量化数据长度不一致: {len(content_vecs)} != {len(data)}")

    # 构建实体列表
    return [{
        "embedding": content_vecs[index]["embedding"],
        "content": single,
        "question_embedding": question_vecs[index]["embedding"],
        "question": user_questions[index]
    } for index, single in enumerate(data)]


def process_metadata(
        content: str,
        text_splitter: RecursiveCharacterTextSplitter
) -> List[Dict[str, Any]]:
    """处理元数据类型的内容"""
    # 分割文本
    documents = text_splitter.split_text(content)
    doc_flag = hashlib.md5(content.encode()).hexdigest()
    total_chunks = str(len(documents))

    # 提取表名称
    table_name = []
    if documents:  # 确保文档列表不为空
        match = re.findall(r'(?<=表名称：).*', str(documents[0]), re.MULTILINE)
        if match:
            table_name.append(match[0].strip())

    # 向量化处理
    table_name_vecs = vectorize_text(table_name)["data"] if table_name else []
    content_vecs = vectorize_text(documents)["data"]

    # 验证向量长度一致性
    if len(content_vecs) != len(documents):
        raise Exception(f"向量化数据长度不一致: {len(content_vecs)} != {len(documents)}")

    # 构建实体列表
    return [{
        "embedding": content_vecs[index]["embedding"],
        "table_name_embedding": table_name_vecs[0]["embedding"] if table_name_vecs else None,
        "table_name": table_name[0] if table_name else None,
        "content": single,
        "doc_flag": doc_flag,
        "chunk_index": str(index),
        "total_chunks": total_chunks,
    } for index, single in enumerate(documents)]


def cleanup_file(file_path: str) -> None:
    """清理本地临时文件"""
    if os.path.exists(file_path):
        os.remove(file_path)
        logging.info(f"删除文件: {file_path}")
